=== Aplinkos Ministerijos - Norway Grants ===
Contributors: aplinkosministerija
Tags: am, rusiavimas
Requires at least: 4.7
Tested up to: 6.3
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin that helps users learn about waste management and disposal

== Description ==

A plugin that helps users learn about waste management and disposal. Insert shortcode [aplinkos-ministerija] into website body.
It provides learning services to people about waste managment, system uses iframe technology which is rendered from Flutter code, no need for account or registration.
Plugin provides another functionality which is sharing, you can share information that you found in this plugin.