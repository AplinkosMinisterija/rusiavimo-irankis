=== Aplinkos Ministerijos - Norway Grants ===
Contributors: aplinkosministerija
Tags: am, rusiavimas
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin that helps users learn about waste management and disposal

== Description ==

A plugin that helps users learn about waste management and disposal. Insert shortcode [aplinkos-ministerija] into website body.